--- PROJECT CORVUS ---

for use primarily for (WIP) Project Corvus roleplay server.
you are allowed to modify parts given in this pack. CREDIT IS REQUIED.

[ SUGGESTIONS & CUSTOM PART COMMISSIONS ]
- requests - https://forms.gle/aVXLptzmyPguCPho8
- commissions - https://forms.gle/mFyrgmfgeqTsJ4TdA


contacts: nymph_bat (twitter) / nymphh (discord)

ko-fi: https://ko-fi.com/nymphbat

moreplayermodels made by noppes
(https://www.curseforge.com/minecraft/mc-mods/more-player-models) 